"""Release Readiness — converts test/security results into a structured verdict."""

from backend.models import ReleaseReadiness, SandboxResult


def evaluate_release_readiness(sandbox_result: SandboxResult) -> ReleaseReadiness:
    """Evaluate release readiness based on sandbox test results.

    Statuses:
    - READY: All tests pass, no critical issues
    - WARNING: Tests pass but there are warnings
    - BLOCKED: Tests fail or critical issues found
    """
    critical_issues = 0
    warnings = 0

    counts = sandbox_result.test_counts

    # Unknown legacy zeros are never passing evidence.
    # Check for critical issues
    if (sandbox_result.status != "passed" or counts is None or counts.total <= 0 or
            counts.passed != counts.total or counts.failed or counts.skipped or
            sandbox_result.runtime_errors):
        critical_issues = max(1, sandbox_result.tests_failed, len(sandbox_result.runtime_errors))

    # Check for security warnings
    warnings += len(sandbox_result.security_warnings)

    # Determine status
    if critical_issues > 0:
        status = "BLOCKED"
    elif warnings > 0:
        status = "WARNING"
    else:
        status = "READY"

    return ReleaseReadiness(
        status=status,
        critical_issues=critical_issues,
        warnings=warnings,
        test_counts=counts,
    )
